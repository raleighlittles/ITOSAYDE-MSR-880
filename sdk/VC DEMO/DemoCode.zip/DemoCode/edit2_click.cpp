// edit2_click.cpp : implementation file
//

#include "stdafx.h"
#include "m160.h"
#include "edit2_click.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Cedit2_click

Cedit2_click::Cedit2_click()
{
}

Cedit2_click::~Cedit2_click()
{
}


BEGIN_MESSAGE_MAP(Cedit2_click, CEdit)
	//{{AFX_MSG_MAP(Cedit2_click)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Cedit2_click message handlers
