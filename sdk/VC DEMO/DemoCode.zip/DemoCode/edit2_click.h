#if !defined(AFX_EDIT2_CLICK_H__E17CCC1F_BD4B_4F53_BA69_CD7C9E5AE9B0__INCLUDED_)
#define AFX_EDIT2_CLICK_H__E17CCC1F_BD4B_4F53_BA69_CD7C9E5AE9B0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// edit2_click.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// Cedit2_click window

class Cedit2_click : public CEdit
{
// Construction
public:
	Cedit2_click();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Cedit2_click)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~Cedit2_click();

	// Generated message map functions
protected:
	//{{AFX_MSG(Cedit2_click)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDIT2_CLICK_H__E17CCC1F_BD4B_4F53_BA69_CD7C9E5AE9B0__INCLUDED_)
